package problem;


public interface Actor {
	public String getId();
	public GridCell getPosition();
}
