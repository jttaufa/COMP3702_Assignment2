package problem;

import java.util.EnumMap;
import java.util.HashMap;

public class RandomPolicy extends HashMap<GridCell, EnumMap<Action, Double>> {
	
}
